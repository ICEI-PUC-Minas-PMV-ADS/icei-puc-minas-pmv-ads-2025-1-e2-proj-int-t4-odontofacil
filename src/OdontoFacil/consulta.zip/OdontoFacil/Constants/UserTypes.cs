namespace OdontoFacil.Constants;

public static class UserTypes
{
    public const string Dentist = "dentista";
    public const string Patient = "paciente";
    public const string Helper = "auxiliar";
}