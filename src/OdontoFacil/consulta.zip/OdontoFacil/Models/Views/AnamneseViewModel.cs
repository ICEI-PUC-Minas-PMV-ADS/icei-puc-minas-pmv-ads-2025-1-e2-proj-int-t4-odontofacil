﻿using System.ComponentModel.DataAnnotations;

namespace OdontoFacil.Models.Views
{
    public class AnamneseViewModel
    {
        [Display(Name = "Queixa Principal")]
        public string QueixaPrincipal { get; set; }

        public bool? UsaMedicacao { get; set; }
        public string MedicacaoQual { get; set; }

        public bool? PossuiAlergia { get; set; }
        public string AlergiaQual { get; set; }

        public bool? PossuiDoenca { get; set; }
        public string DoencaQual { get; set; }

        public bool? FezCirurgia { get; set; }
        public string CirurgiaQual { get; set; }

        public bool? SangramentoGengiva { get; set; }
        public string SangramentoQual { get; set; }

        public bool? Bruxismo { get; set; }
        public string BruxismoQual { get; set; }

        public bool? DorDentes { get; set; }
        public string DorDentesQual { get; set; }

        public bool? BocaSeca { get; set; }
        public string BocaSecaQual { get; set; }

        public bool? DorMaxilar { get; set; }
        public string DorMaxilarQual { get; set; }

        public string Observacoes { get; set; }
    }
}
